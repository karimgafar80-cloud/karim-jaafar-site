'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowDown, ArrowUpRight, Menu, Play, Volume2, VolumeX, X } from 'lucide-react'

const SHOWREEL_URL = 'https://vimeo.com/1157962782'

type Project = {
  title: string
  type: string
  year: string
  description: string
  role: string
  poster?: string
  stills: string[]
  behindTheScenes?: string[]
  recognition?: string[]
  note?: string
}

const projects: Project[] = [
  {
    title: 'Andromeda',
    type: 'Feature / short drama · In development',
    year: '2026',
    description: "A Syrian refugee mother in Egypt races against a brutal medical clock to fund her daughter's urgent surgery.",
    role: 'Writer / Director',
    stills: [],
    note: 'Currently in development. Pitch materials, treatment and look-book are available on request.',
  },
  {
    title: 'Euphorbia',
    type: 'Short thriller · 30+ festivals',
    year: '2024',
    description: 'Selected across international festivals including Ferrara, Tokyo, Russia, and the UK.',
    role: 'Director',
    poster: '/films/euphorbia-poster.jpg',
    stills: ['/films/euphorbia-1.jpg', '/films/euphorbia-2.jpg', '/films/euphorbia-3.jpg', '/films/euphorbia-4.jpg'],
    behindTheScenes: ['/films/euphorbia-bts-1.jpg', '/films/euphorbia-bts-2.jpg'],
    recognition: [
      'Special Jury Mention — Five Second Film Festival (UK)',
      'Special Mention — Empowered Woman Festival (Tokyo)',
      "Best Actress, Noor Salman — Kino Festival (Russia)",
      'Official Selection — Ferrara Film Festival (Italy)',
      'International theatrical screenings — Greece',
    ],
  },
  {
    title: 'Rights Wine',
    type: 'Debut short · Social drama',
    year: '2023',
    description: 'A raw social drama examining power, unemployment, and harassment in urban Egypt.',
    role: 'Director',
    poster: '/films/rights-wine-poster.jpg',
    stills: ['/films/rights-wine-1.jpg', '/films/rights-wine-2.jpg', '/films/rights-wine-3.jpg', '/films/rights-wine-4.jpg', '/films/rights-wine-5.jpg'],
    note: 'My first project as a director.',
  },
]

const awards = projects.find((p) => p.title === 'Euphorbia')?.recognition ?? []

const creativeSkills = ['Directing', 'Storytelling', 'Script development', 'Visual composition', 'Creative concepting']
const productionSkills = ['On-set direction', 'Team management', 'Client communication', 'Production planning']

const cardImages: Record<string, { url: string; position: string; grain: boolean; filter: string }> = {
  Andromeda: {
    url: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Soldiers_standing_at_hole_edge_202609052303-Xb5GBq6tLZtj4ahzXxvDm3Bb7mijKN.jpeg',
    position: '68% center',
    grain: true,
    filter: 'grayscale(100%) contrast(150%) brightness(75%)',
  },
  Euphorbia: {
    url: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/42_1.93.1-4coaugrYHFaYoRIztZ9P9OhXb8VPTX.jpg',
    position: '50% center',
    grain: false,
    filter: 'grayscale(100%) contrast(145%) brightness(75%)',
  },
  'Rights Wine': {
    url: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202024-11-24%20at%2004.53.16_6a0e45a8-vqs6YmpnNXDPCZF7YRD8b1wPWeuShz.jpg',
    position: '50% center',
    grain: true,
    filter: 'grayscale(100%) contrast(150%) brightness(75%)',
  },
}

export function Portfolio() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [contactOpen, setContactOpen] = useState(false)
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [isMuted, setIsMuted] = useState(true)
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    audio.volume = 0.35
    audio.muted = true
    void audio.play().catch(() => {
      // Browsers may still defer autoplay until the first user gesture.
    })
  }, [])

  useEffect(() => {
    if (!contactOpen && !selectedProject) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return
      setContactOpen(false)
      setSelectedProject(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [contactOpen, selectedProject])

  const toggleSound = () => {
    const audio = audioRef.current
    if (!audio) return

    const nextMuted = !isMuted
    audio.muted = nextMuted
    setIsMuted(nextMuted)
    if (!nextMuted) void audio.play().catch(() => undefined)
  }

  const closeMenu = () => setMenuOpen(false)
  const activeProject = projects.find((p) => p.title === selectedProject)

  return (
    <main className="min-h-screen overflow-hidden bg-[#090909] text-[#f1eee8]">
      <audio ref={audioRef} id="bgMusic" src="/background-audio.mp3" loop autoPlay muted preload="auto" aria-label="Ambient cinematic background music" />
      <button type="button" onClick={toggleSound} aria-label={isMuted ? 'Turn sound on' : 'Turn sound off'} aria-pressed={!isMuted} className="fixed bottom-6 right-6 z-40 flex size-11 items-center justify-center rounded-full border border-white/25 bg-black/70 text-white/75 shadow-2xl backdrop-blur-md transition-colors hover:border-white/60 hover:bg-white hover:text-black focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white">
        {isMuted ? <VolumeX aria-hidden="true" /> : <Volume2 aria-hidden="true" />}
      </button>
      <div className="film-grain" aria-hidden="true" />
      <header className="fixed inset-x-0 top-0 z-40 border-b border-white/10 bg-[#090909]/80 backdrop-blur-md">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 lg:px-10">
          <a href="#top" className="font-display text-sm font-semibold tracking-[0.22em]">KARIM JAAFAR</a>
          <nav className="hidden items-center gap-8 text-[10px] uppercase tracking-[0.24em] text-white/55 md:flex">
            <a href="#reel" className="transition-colors hover:text-white">Reel</a>
            <a href="#work" className="transition-colors hover:text-white">Work</a>
            <a href="#recognition" className="transition-colors hover:text-white">Recognition</a>
            <a href="#about" className="transition-colors hover:text-white">About</a>
            <button onClick={() => setContactOpen(true)} className="border border-white/35 px-5 py-3 text-white transition-colors hover:bg-white hover:text-black">Contact</button>
          </nav>
          <button aria-label="Open menu" onClick={() => setMenuOpen(!menuOpen)} className="md:hidden"><Menu size={21} strokeWidth={1.5} /></button>
        </div>
        {menuOpen && <nav className="border-t border-white/10 bg-[#111]/95 px-6 py-6 md:hidden"><div className="flex flex-col gap-5 text-[10px] uppercase tracking-[0.24em] text-white/65"><a href="#reel" onClick={closeMenu}>Reel</a><a href="#work" onClick={closeMenu}>Work</a><a href="#recognition" onClick={closeMenu}>Recognition</a><a href="#about" onClick={closeMenu}>About</a><button className="border border-white/30 px-4 py-3 text-left text-white" onClick={() => { closeMenu(); setContactOpen(true) }}>Contact</button></div></nav>}
      </header>

      <section id="top" className="relative flex min-h-[92vh] items-end overflow-hidden px-6 pb-18 pt-32 lg:min-h-screen lg:px-10 lg:pb-24">
        <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/453defcf-c838-47cd-b9dd-ddafd9d5dcd8.jfif-3VkyJGaz7usUU1fnmN9IcJB00mteVt.jpeg" alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover object-[center_22%] grayscale opacity-45" />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(9,9,9,.98)_0%,rgba(9,9,9,.78)_38%,rgba(9,9,9,.24)_100%),linear-gradient(0deg,rgba(9,9,9,.98)_0%,transparent_55%)]" aria-hidden="true" />
        <div className="hero-glow" aria-hidden="true" />
        <div className="relative z-10 mx-auto w-full max-w-7xl">
          <p className="mb-7 text-[10px] uppercase tracking-[0.34em] text-white/50">Film Director · Screenwriter · Creative Storyteller</p>
          <h1 className="max-w-5xl font-display text-[clamp(4rem,12vw,11rem)] font-medium uppercase leading-[0.8] tracking-[-0.07em]">Karim<br /><span className="text-white/45">Jaafar</span></h1>
          <div className="mt-12 flex flex-col justify-between gap-8 border-t border-white/15 pt-6 md:flex-row md:items-end"><p className="max-w-md text-base font-light leading-relaxed text-white/60">Egyptian filmmaker crafting visceral narratives, psychological drama, and high-contrast social realism that resonates internationally.</p><a href="#reel" className="group flex items-center gap-3 text-[10px] uppercase tracking-[0.24em]">Watch the showreel <span className="flex h-10 w-10 items-center justify-center rounded-full border border-white/30 transition-colors group-hover:bg-white group-hover:text-black"><Play size={12} fill="currentColor" /></span></a></div>
        </div>
      </section>

      <section id="reel" className="border-y border-white/10 bg-[#111] px-6 py-24 lg:px-10 lg:py-32">
        <div className="mx-auto max-w-7xl"><div className="mb-10 flex items-end justify-between border-b border-white/15 pb-5"><div><p className="mb-2 text-[10px] uppercase tracking-[0.28em] text-white/45">01 / Cinematic reel</p><h2 className="font-display text-3xl uppercase tracking-[-0.03em] md:text-5xl">Director&apos;s cut</h2></div><span className="hidden text-[10px] uppercase tracking-[0.2em] text-white/40 md:block">Vimeo · 2025</span></div><div className="reel-card relative aspect-video overflow-hidden border border-white/15 bg-black"><iframe src="https://player.vimeo.com/video/1157962782" title="Karim Jaafar showreel" className="absolute inset-0 h-full w-full" frameBorder="0" allow="autoplay; fullscreen; picture-in-picture" allowFullScreen /></div></div>
      </section>

      <section id="work" className="px-6 py-24 lg:px-10 lg:py-32">
        <div className="mx-auto max-w-7xl">
          <div className="mb-14 flex items-end justify-between border-b border-white/15 pb-5"><div><p className="mb-2 text-[10px] uppercase tracking-[0.28em] text-white/45">02 / Selected filmography</p><h2 className="font-display text-3xl uppercase tracking-[-0.03em] md:text-5xl">The slate</h2></div><span className="text-[10px] uppercase tracking-[0.2em] text-white/40">0{projects.length} projects</span></div>
          <div className="grid gap-px border border-white/15 bg-white/15 md:grid-cols-3">
            {projects.map((project, index) => {
              const image = cardImages[project.title]
              return (
                <button key={project.title} onClick={() => setSelectedProject(project.title)} className="group relative min-h-85 overflow-hidden bg-[#090909] p-7 text-left transition-colors hover:bg-[#191918] lg:p-9">
                  {image && <><div className="absolute inset-0 bg-cover" style={{ backgroundImage: `url("${image.url}")`, backgroundPosition: image.position, filter: image.filter }} aria-hidden="true" /><div className="absolute inset-0 bg-[#090909]/[0.18]" aria-hidden="true" />{image.grain && <div className="film-grain absolute inset-0 opacity-30" aria-hidden="true" />}</>}
                  <div className="relative z-10 flex items-start justify-between text-[9px] uppercase tracking-[0.2em] text-white/45"><span>0{index + 1} / {project.type}</span><span>{project.year}</span></div>
                  <div className="relative z-10 mt-28">
                    <h3 className="font-display text-3xl uppercase tracking-[-0.03em] transition-transform group-hover:translate-x-2">{project.title}</h3>
                    <p className="mt-4 max-w-xs text-sm font-light leading-relaxed text-white/50">{project.description}</p>
                    <span className="mt-7 inline-flex items-center gap-2 text-[9px] uppercase tracking-[0.2em] text-white/60">View project <ArrowUpRight size={13} /></span>
                  </div>
                </button>
              )
            })}
          </div>
        </div>
      </section>

      <section id="recognition" className="border-y border-white/10 bg-[#111] px-6 py-24 lg:px-10 lg:py-32">
        <div className="mx-auto max-w-7xl">
          <div className="mb-14 flex items-end justify-between border-b border-white/15 pb-5"><div><p className="mb-2 text-[10px] uppercase tracking-[0.28em] text-white/45">03 / Awards &amp; recognition</p><h2 className="font-display text-3xl uppercase tracking-[-0.03em] md:text-5xl">Euphorbia</h2></div><span className="hidden text-[10px] uppercase tracking-[0.2em] text-white/40 md:block">The Exhausted Flower · 2024</span></div>
          <ul className="grid gap-px border border-white/15 bg-white/15">
            {awards.map((award) => {
              const [title, festival] = award.split(' — ')
              return (
                <li key={award} className="flex flex-col justify-between gap-2 bg-[#111] px-6 py-6 md:flex-row md:items-baseline lg:px-9">
                  <span className="font-display text-xl uppercase tracking-[-0.02em] md:text-2xl">{title}</span>
                  {festival && <span className="text-[10px] uppercase tracking-[0.22em] text-white/50">{festival}</span>}
                </li>
              )
            })}
          </ul>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {['/films/screening-ferrara.jpg', '/films/screening-hall.jpg', '/films/screening-bts.jpg'].map((src) => (
              <img key={src} src={src} alt="Euphorbia festival screening and behind the scenes" loading="lazy" className="aspect-[3/2] w-full object-cover grayscale transition duration-500 hover:grayscale-0" />
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="px-6 py-24 lg:px-10 lg:py-32">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.72fr_1fr_1.4fr] lg:items-start">
          <p className="text-[10px] uppercase tracking-[0.28em] text-white/45">04 / The director</p>
          <div className="lg:col-span-2">
            <p className="max-w-3xl font-display text-3xl uppercase leading-[1.05] tracking-[-0.04em] md:text-6xl">Cinema is truth spoken in shadows.</p>
            <div className="mt-12 grid gap-8 border-t border-white/15 pt-6 text-sm font-light leading-relaxed text-white/55 md:grid-cols-2">
              <p>Egyptian filmmaker and director with experience in narrative filmmaking and production leadership. I approach cinema without fluff: strong visual composition, precise pacing, and uncompromised human realism.</p>
              <p>My work focuses on social dynamics, displacement, and power structures, with over 30 international festival selections. I&apos;ve directed two independent narrative films and developed several short film concepts, including Andromeda. Available for features, writing, and collaborations.</p>
            </div>
            <div className="mt-12 grid gap-px border border-white/15 bg-white/15 md:grid-cols-2">
              <div className="bg-[#090909] p-7 lg:p-9"><p className="text-[10px] uppercase tracking-[0.28em] text-white/45">Creative</p><ul className="mt-5 space-y-2 font-display text-lg uppercase tracking-[-0.01em]">{creativeSkills.map((s) => <li key={s}>{s}</li>)}</ul></div>
              <div className="bg-[#090909] p-7 lg:p-9"><p className="text-[10px] uppercase tracking-[0.28em] text-white/45">Production</p><ul className="mt-5 space-y-2 font-display text-lg uppercase tracking-[-0.01em]">{productionSkills.map((s) => <li key={s}>{s}</li>)}</ul></div>
            </div>
            <blockquote className="mt-16 border-l border-white/30 pl-6">
              <p className="text-[10px] uppercase tracking-[0.28em] text-white/45">Artistic vision</p>
              <p className="mt-4 max-w-3xl font-display text-2xl uppercase leading-[1.1] tracking-[-0.03em] md:text-4xl">Creating emotionally resonant films that transcend borders and connect cultures through storytelling.</p>
            </blockquote>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 px-6 py-12 lg:px-10"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-8 md:flex-row md:items-end"><div><p className="font-display text-2xl uppercase tracking-[-0.03em]">Let&apos;s tell the big<br />stories.</p><button onClick={() => setContactOpen(true)} className="mt-6 inline-flex items-center gap-3 border-b border-white/50 pb-2 text-[10px] uppercase tracking-[0.22em]">Start a conversation <ArrowDown size={13} /></button></div><div className="text-[10px] uppercase tracking-[0.2em] text-white/40"><p>© 2026 Karim Jaafar</p><p className="mt-2">All images, all stories.</p></div></div></footer>

      {contactOpen && <div role="dialog" aria-modal="true" aria-label="Contact Karim Jaafar" onClick={() => setContactOpen(false)} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-6 backdrop-blur-sm"><div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-lg border border-white/20 bg-[#151514] p-8 md:p-12"><button aria-label="Close contact dialog" onClick={() => setContactOpen(false)} className="absolute right-5 top-5 text-white/50 hover:text-white"><X size={18} /></button><p className="text-[10px] uppercase tracking-[0.25em] text-white/45">Contact</p><h2 className="mt-4 font-display text-4xl uppercase">Start a conversation.</h2><p className="mt-5 text-sm leading-relaxed text-white/55">For directing, writing, and production inquiries, reach out at <a className="text-white underline underline-offset-4" href="mailto:karimgafar80@gmail.com">karimgafar80@gmail.com</a>.</p><a href={SHOWREEL_URL} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-white/70 hover:text-white">Showreel on Vimeo <ArrowUpRight size={13} /></a></div></div>}

      {activeProject && (
        <div role="dialog" aria-modal="true" aria-label={`${activeProject.title} project details`} onClick={() => setSelectedProject(null)} className="fixed inset-0 z-50 overflow-y-auto bg-black/85 p-4 backdrop-blur-sm md:p-8">
          <div onClick={(e) => e.stopPropagation()} className="relative mx-auto w-full max-w-4xl border border-white/20 bg-[#151514] p-6 md:p-12">
            <button aria-label="Close project dialog" onClick={() => setSelectedProject(null)} className="absolute right-5 top-5 text-white/50 hover:text-white"><X size={18} /></button>
            <p className="text-[10px] uppercase tracking-[0.25em] text-white/45">{activeProject.type} · {activeProject.year}</p>
            <h2 className="mt-4 font-display text-5xl uppercase md:text-7xl">{activeProject.title}</h2>
            <div className="mt-8 grid gap-8 md:grid-cols-[1fr_auto] md:items-start">
              <div>
                <p className="max-w-xl text-base font-light leading-relaxed text-white/65">{activeProject.description}</p>
                <p className="mt-6 text-[10px] uppercase tracking-[0.22em] text-white/45">Role · <span className="text-white/80">{activeProject.role}</span></p>
                {activeProject.note && <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/50">{activeProject.note}</p>}
                {activeProject.recognition && <ul className="mt-8 space-y-3 border-t border-white/15 pt-6 text-sm text-white/70">{activeProject.recognition.map((r) => <li key={r}>{r}</li>)}</ul>}
              </div>
              {activeProject.poster && <img src={activeProject.poster} alt={`${activeProject.title} poster`} className="w-44 border border-white/15 md:w-52" />}
            </div>
            {activeProject.stills.length > 0 && (
              <div className="mt-10">
                <p className="mb-4 text-[10px] uppercase tracking-[0.25em] text-white/45">Framing</p>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
                  {activeProject.stills.map((src) => <img key={src} src={src} alt={`${activeProject.title} still`} loading="lazy" className="aspect-[3/2] w-full object-cover grayscale transition duration-500 hover:grayscale-0" />)}
                </div>
              </div>
            )}
            {activeProject.behindTheScenes && (
              <div className="mt-10">
                <p className="mb-4 text-[10px] uppercase tracking-[0.25em] text-white/45">Behind the scenes</p>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
                  {activeProject.behindTheScenes.map((src) => <img key={src} src={src} alt={`${activeProject.title} behind the scenes`} loading="lazy" className="aspect-[3/2] w-full object-cover grayscale transition duration-500 hover:grayscale-0" />)}
                </div>
              </div>
            )}
            <button onClick={() => { setSelectedProject(null); setContactOpen(true) }} className="mt-10 border border-white/35 px-5 py-3 text-[10px] uppercase tracking-[0.2em] hover:bg-white hover:text-black">Request materials</button>
          </div>
        </div>
      )}
    </main>
  )
}
