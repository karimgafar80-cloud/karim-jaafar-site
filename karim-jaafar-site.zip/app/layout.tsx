import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Karim Jaafar | Director & Screenwriter',
  description: 'Karim Jaafar is an Egyptian director and screenwriter crafting high-contrast narrative cinema and social realism. Award-winning short films: Euphorbia, Rights Wine.',
  openGraph: {
    title: 'Karim Jaafar | Director & Screenwriter',
    description: 'Egyptian director and screenwriter. Award-winning short films Euphorbia and Rights Wine.',
    type: 'website',
    images: [{ url: '/films/euphorbia-poster.jpg' }],
  },
  verification: {
    google: 'iQLWJ50D8Jy1YlTuUKYC-339hBvPeXBZWMWmB-a0mbk',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: 'white' },
    { media: '(prefers-color-scheme: dark)', color: 'black' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
